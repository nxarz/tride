using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public float moveSpeed = 2f;
    public float runSpeed = 4f;
    public float jumpForce = 10f;
    public float mouseX = 500f;
    public float mouseY = 500f;
    public float maxAngle = 70f, minAngle = -60f;
    public Transform cam;
    public Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        //Cursor.lockState = CursorLockMode.Locked;
    }

    bool jumpCommand = false;
    float angle = 0;
    void Update()
    {
        jumpCommand |= Input.GetButtonDown("Jump");
        var mouseInput = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
        transform.rotation *= Quaternion.Euler(0, mouseInput.x * mouseX * Time.deltaTime, 0);
        angle = Mathf.Clamp(angle - mouseInput.y * mouseY * Time.deltaTime, -maxAngle, -minAngle);
        cam.localRotation = Quaternion.Euler(angle, 0, 0);
    }

    private void FixedUpdate()
    {
        var motionInput = transform.rotation * new Vector3(Input.GetAxis("Horizontal"), 0,
            Input.GetAxis("Vertical"));
        motionInput.x += rb.velocity.x;
        motionInput.x += rb.velocity.z;
        var speed = Input.GetButton("Fire3") ? runSpeed : moveSpeed;
        motionInput = Vector3.ClampMagnitude(motionInput, speed);
        motionInput.y = rb.velocity.y;
        if (jumpCommand)
        {
            jumpCommand = false;
            motionInput.y = jumpForce;
        }
        rb.velocity = motionInput;
    }
}
